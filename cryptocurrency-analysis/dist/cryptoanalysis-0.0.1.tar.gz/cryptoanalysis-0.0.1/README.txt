It is a python library I created for fun. It does a simple analysis of cryptocurrencies and plots a few graphs to help visualize the trends.

